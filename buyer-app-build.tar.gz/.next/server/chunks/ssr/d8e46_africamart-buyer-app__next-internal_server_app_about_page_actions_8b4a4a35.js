module.exports=[17413,(a,b,c)=>{}];

//# sourceMappingURL=d8e46_africamart-buyer-app__next-internal_server_app_about_page_actions_8b4a4a35.js.map