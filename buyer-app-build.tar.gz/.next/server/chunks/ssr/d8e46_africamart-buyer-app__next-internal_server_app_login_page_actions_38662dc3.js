module.exports=[1629,(a,b,c)=>{}];

//# sourceMappingURL=d8e46_africamart-buyer-app__next-internal_server_app_login_page_actions_38662dc3.js.map