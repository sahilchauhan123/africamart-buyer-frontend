module.exports=[8900,(a,b,c)=>{}];

//# sourceMappingURL=11796__next-internal_server_app_product_%5Bslug%5D_page_actions_4decc952.js.map