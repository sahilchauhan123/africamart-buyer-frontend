module.exports=[51212,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},21261,a=>{"use strict";let b={src:a.i(51212).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Desktop_react_project_seller-africa-mart_africamart-buyer-app_app_7db291ef._.js.map