module.exports=[73357,(a,b,c)=>{}];

//# sourceMappingURL=d8e46_africamart-buyer-app__next-internal_server_app_chat_page_actions_7a72f300.js.map