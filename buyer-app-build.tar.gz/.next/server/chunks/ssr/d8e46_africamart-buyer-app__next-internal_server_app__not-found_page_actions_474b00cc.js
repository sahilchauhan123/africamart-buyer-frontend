module.exports=[58132,(a,b,c)=>{}];

//# sourceMappingURL=d8e46_africamart-buyer-app__next-internal_server_app__not-found_page_actions_474b00cc.js.map