module.exports=[36160,(a,b,c)=>{}];

//# sourceMappingURL=11796__next-internal_server_app_categories_%5B___path%5D_page_actions_f46abe8f.js.map