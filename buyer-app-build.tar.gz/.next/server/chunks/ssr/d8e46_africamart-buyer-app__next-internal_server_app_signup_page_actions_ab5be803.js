module.exports=[95298,(a,b,c)=>{}];

//# sourceMappingURL=d8e46_africamart-buyer-app__next-internal_server_app_signup_page_actions_ab5be803.js.map