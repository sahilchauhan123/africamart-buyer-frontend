module.exports=[45439,(a,b,c)=>{}];

//# sourceMappingURL=11796__next-internal_server_app__global-error_page_actions_910160d8.js.map