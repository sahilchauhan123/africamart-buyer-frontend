module.exports=[82755,(a,b,c)=>{}];

//# sourceMappingURL=d8e46_africamart-buyer-app__next-internal_server_app_search_page_actions_d82b085a.js.map