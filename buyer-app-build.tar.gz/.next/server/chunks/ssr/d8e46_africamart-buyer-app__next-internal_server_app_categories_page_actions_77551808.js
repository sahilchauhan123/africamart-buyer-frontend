module.exports=[13741,(a,b,c)=>{}];

//# sourceMappingURL=d8e46_africamart-buyer-app__next-internal_server_app_categories_page_actions_77551808.js.map