module.exports=[99083,(a,b,c)=>{}];

//# sourceMappingURL=11796__next-internal_server_app_seller_%5Bslug%5D_page_actions_f824446d.js.map