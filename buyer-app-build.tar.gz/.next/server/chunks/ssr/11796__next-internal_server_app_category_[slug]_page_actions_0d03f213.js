module.exports=[44110,(a,b,c)=>{}];

//# sourceMappingURL=11796__next-internal_server_app_category_%5Bslug%5D_page_actions_0d03f213.js.map