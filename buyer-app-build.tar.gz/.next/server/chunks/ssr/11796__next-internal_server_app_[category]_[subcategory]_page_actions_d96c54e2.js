module.exports=[11562,(a,b,c)=>{}];

//# sourceMappingURL=11796__next-internal_server_app_%5Bcategory%5D_%5Bsubcategory%5D_page_actions_d96c54e2.js.map