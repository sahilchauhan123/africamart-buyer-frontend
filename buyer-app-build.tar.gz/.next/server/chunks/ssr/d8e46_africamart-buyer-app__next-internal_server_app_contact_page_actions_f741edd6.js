module.exports=[85276,(a,b,c)=>{}];

//# sourceMappingURL=d8e46_africamart-buyer-app__next-internal_server_app_contact_page_actions_f741edd6.js.map