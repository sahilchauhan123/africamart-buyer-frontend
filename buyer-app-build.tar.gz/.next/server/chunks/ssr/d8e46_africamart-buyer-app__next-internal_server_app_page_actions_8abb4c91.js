module.exports=[41860,(a,b,c)=>{}];

//# sourceMappingURL=d8e46_africamart-buyer-app__next-internal_server_app_page_actions_8abb4c91.js.map