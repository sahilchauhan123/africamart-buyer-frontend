module.exports=[35760,(e,o,d)=>{}];

//# sourceMappingURL=11796__next-internal_server_app_favicon_ico_route_actions_28e48e42.js.map