1:"$Sreact.fragment"
2:I[32558,["/_next/static/chunks/4198c68e45f75317.js","/_next/static/chunks/d2e8392039c94e0a.js"],"ViewportBoundary"]
3:I[32558,["/_next/static/chunks/4198c68e45f75317.js","/_next/static/chunks/d2e8392039c94e0a.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[75877,["/_next/static/chunks/4198c68e45f75317.js","/_next/static/chunks/d2e8392039c94e0a.js"],"IconMark"]
0:{"buildId":"1g6p-K8BhptOFVVh_G40Y","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Contact Us | AfricaMart"}],["$","meta","1",{"name":"description","content":"Get in touch with AfricaMart support."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
