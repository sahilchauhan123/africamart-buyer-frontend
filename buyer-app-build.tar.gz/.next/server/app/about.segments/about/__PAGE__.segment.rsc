1:"$Sreact.fragment"
2:I[32558,["/_next/static/chunks/4198c68e45f75317.js","/_next/static/chunks/d2e8392039c94e0a.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"1g6p-K8BhptOFVVh_G40Y","rsc":["$","$1","c",{"children":[["$","div",null,{"children":"About AfricaMart"}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
