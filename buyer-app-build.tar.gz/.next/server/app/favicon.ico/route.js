var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__73c679df._.js")
R.c("server/chunks/11796__next-internal_server_app_favicon_ico_route_actions_28e48e42.js")
R.m(26833)
module.exports=R.m(26833).exports
