1:"$Sreact.fragment"
2:I[52245,["/_next/static/chunks/4198c68e45f75317.js","/_next/static/chunks/d2e8392039c94e0a.js"],"default"]
3:I[50619,["/_next/static/chunks/4198c68e45f75317.js","/_next/static/chunks/d2e8392039c94e0a.js"],"default"]
0:{"buildId":"1g6p-K8BhptOFVVh_G40Y","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
